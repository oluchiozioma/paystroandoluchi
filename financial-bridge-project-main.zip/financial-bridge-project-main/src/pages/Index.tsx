import { useState } from "react";
import OverviewSection from "@/components/paystro/sections/OverviewSection";
import WalletStrategySection from "@/components/paystro/sections/WalletStrategySection";
import TrustCampaignsSection from "@/components/paystro/sections/TrustCampaignsSection";
import ImpactSection from "@/components/paystro/sections/ImpactSection";
import paystroLogo from "@/assets/paystro-logo-white.png";

const sections = ["Overview", "Wallet Strategy", "Trust Campaigns", "Expected Impact"];

const Index = () => {
  const [activeSection, setActiveSection] = useState("Overview");

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 bg-background/80 backdrop-blur-md z-50 border-b border-border">
        <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
          <h1 className="font-serif text-xl font-semibold text-foreground">Paystro</h1>
          <nav className="hidden md:flex items-center gap-8">
            {sections.map((section) => (
              <button
                key={section}
                onClick={() => setActiveSection(section)}
                className={`text-sm transition-colors ${
                  activeSection === section
                    ? "text-primary font-medium"
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                {section}
              </button>
            ))}
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-6">
        <div className="max-w-6xl mx-auto grid lg:grid-cols-2 gap-16 items-center">
          <div className="animate-fade-in-up">
            <span className="text-xs uppercase tracking-widest text-primary font-medium">
              Product Strategy
            </span>
            <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl text-foreground mt-4 leading-tight">
              Building Financial Inclusion Through Trust
            </h1>
            <p className="text-muted-foreground text-lg mt-6 leading-relaxed max-w-xl">
              A wallet-powered strategy for Paystro that positions the wallet as the future foundation for bill payments and the P2P marketplace. By simplifying the user experience and pairing it with education-first campaigns, Paystro can turn competitive features into intuitive, purpose-driven tools for the diaspora community.
            </p>
            <p className="text-muted-foreground/80 italic mt-4 text-base">
              "For financial inclusion, education is not marketing—it's part of the product."
            </p>
            <div className="flex flex-wrap gap-4 mt-8">
              <button
                onClick={() => setActiveSection("Wallet Strategy")}
                className="bg-primary text-primary-foreground px-6 py-3 rounded-lg text-sm font-medium hover:opacity-90 transition-opacity"
              >
                View Strategy
              </button>
              <button
                onClick={() => setActiveSection("Expected Impact")}
                className={`px-6 py-3 rounded-lg text-sm font-medium transition-colors ${
                  activeSection === "Expected Impact"
                    ? "bg-primary text-primary-foreground"
                    : "border border-border text-foreground hover:bg-muted"
                }`}
              >
                See Impact
              </button>
            </div>
          </div>
          <div className="hidden lg:flex justify-center animate-fade-in-up" style={{ animationDelay: "0.2s" }}>
            <img src={paystroLogo} alt="Paystro Logo" className="w-96 h-auto object-contain rounded-2xl shadow-card" />
          </div>
        </div>
        <div className="max-w-6xl mx-auto mt-16 flex justify-center">
          <div className="flex flex-col items-center text-muted-foreground text-sm">
            <span>Scroll</span>
            <span className="mt-2">↓</span>
          </div>
        </div>
      </section>

      {/* Mobile Navigation */}
      <div className="md:hidden sticky top-16 bg-background/95 backdrop-blur-md z-40 px-6 py-4 border-b border-border overflow-x-auto">
        <div className="flex gap-4">
          {sections.map((section) => (
            <button
              key={section}
              onClick={() => setActiveSection(section)}
              className={`text-sm whitespace-nowrap transition-colors px-4 py-2 rounded-full ${
                activeSection === section
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:text-foreground bg-muted"
              }`}
            >
              {section}
            </button>
          ))}
        </div>
      </div>

      {/* Stats Section */}
      <section className="py-16 px-6 border-y border-border bg-muted/30">
        <div className="max-w-6xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-8">
          <div className="text-center">
            <p className="font-serif text-3xl md:text-4xl text-foreground">3</p>
            <p className="text-muted-foreground text-sm mt-2">Core Strategies</p>
          </div>
          <div className="text-center">
            <p className="font-serif text-3xl md:text-4xl text-foreground">4</p>
            <p className="text-muted-foreground text-sm mt-2">Trust Campaigns</p>
          </div>
          <div className="text-center">
            <p className="font-serif text-3xl md:text-4xl text-foreground">6+</p>
            <p className="text-muted-foreground text-sm mt-2">Languages Supported</p>
          </div>
          <div className="text-center">
            <p className="font-serif text-3xl md:text-4xl text-foreground">↑</p>
            <p className="text-muted-foreground text-sm mt-2">Trust & Retention</p>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-20 px-6">
        <div className="max-w-6xl mx-auto">
          {/* Section Header */}
          <div className="mb-12">
            <span className="text-xs uppercase tracking-widest text-primary font-medium">
              {activeSection}
            </span>
            <h2 className="font-serif text-3xl md:text-4xl text-foreground mt-3">
              {activeSection === "Overview" && "Strategic Vision"}
              {activeSection === "Wallet Strategy" && "Wallet-Powered Solutions"}
              {activeSection === "Trust Campaigns" && "Building Trust Through Education"}
              {activeSection === "Expected Impact" && "Measuring Success"}
            </h2>
          </div>

          {/* Content Sections */}
          {activeSection === "Overview" && <OverviewSection />}
          {activeSection === "Wallet Strategy" && <WalletStrategySection />}
          {activeSection === "Trust Campaigns" && <TrustCampaignsSection />}
          {activeSection === "Expected Impact" && <ImpactSection />}
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-6 border-t border-border">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="text-center md:text-left">
            <p className="font-serif text-lg text-foreground">Paystro Strategy</p>
            <p className="text-muted-foreground text-sm mt-1">Building Financial Inclusion</p>
          </div>
          <button
            onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
            className="text-muted-foreground hover:text-foreground text-sm transition-colors"
          >
            Back to top ↑
          </button>
        </div>
      </footer>
    </div>
  );
};

export default Index;