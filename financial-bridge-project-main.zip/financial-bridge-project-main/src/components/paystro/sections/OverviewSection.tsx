const OverviewSection = () => {
  return (
    <div className="space-y-12 animate-fade-in">
      {/* Challenge & Opportunity */}
      <div className="grid md:grid-cols-2 gap-8">
        <div className="bg-problem-bg border border-problem/20 rounded-xl p-8">
          <h3 className="font-serif text-xl text-foreground mb-4">The Problem</h3>
          <p className="text-muted-foreground leading-relaxed">
            Paystro's core differentiators; P2P marketplace and integrated bill payments, offer significant value to users seeking fast, affordable cross-border financial services. However, for new and less tech-savvy users, these features can feel unfamiliar, complex, or even risky. This perception gap creates friction in onboarding, reduces feature adoption, and contributes to lower trust metrics, as reflected in Paystro's 3.7 Trustpilot rating.
          </p>
        </div>
        
        <div className="bg-opportunity-bg border border-opportunity/20 rounded-xl p-8">
          <h3 className="font-serif text-xl text-foreground mb-4">The Opportunity</h3>
          <p className="text-muted-foreground leading-relaxed">
            Build Paystro's wallet feature as the foundational hub for its core differentiators; bill payments and the P2P marketplace, by streamlining the user experience around a single, trusted financial tool. By pairing this with education-first campaigns and transparent UX, we can reduce perceived complexity, build trust among less tech-savvy users, and drive adoption. This approach not only strengthens Paystro's value proposition but also improves public perception and engagement, unlocking long-term growth in underserved remittance corridors.
          </p>
        </div>
      </div>

      {/* Core Recommendations */}
      <div>
        <h3 className="font-serif text-2xl text-foreground mb-8">Core Recommendations</h3>
        <div className="space-y-6">
          <div className="flex gap-6 items-start p-6 bg-card rounded-xl border border-border hover:border-secondary/50 transition-colors">
            <div className="w-12 h-12 rounded-full bg-secondary/10 flex items-center justify-center flex-shrink-0">
              <span className="text-secondary font-serif text-xl">1</span>
            </div>
            <div>
              <h4 className="font-medium text-foreground text-lg">Wallet-First Bill Payments</h4>
              <p className="text-muted-foreground mt-2 leading-relaxed">
                Enable direct bill payments with scheduling and naming (e.g., "Mum's NEPA", "Sister's School Fees")
              </p>
            </div>
          </div>
          
          <div className="flex gap-6 items-start p-6 bg-card rounded-xl border border-border hover:border-primary/50 transition-colors">
            <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
              <span className="text-primary font-serif text-xl">2</span>
            </div>
            <div>
              <h4 className="font-medium text-foreground text-lg">P2P Wallet Integration</h4>
              <p className="text-muted-foreground mt-2 leading-relaxed">
                Use wallet as transparent middle layer showing transaction progress and trader trust signals
              </p>
            </div>
          </div>
          
          <div className="flex gap-6 items-start p-6 bg-card rounded-xl border border-border hover:border-amber-500/50 transition-colors">
            <div className="w-12 h-12 rounded-full bg-amber-500/10 flex items-center justify-center flex-shrink-0">
              <span className="text-amber-600 font-serif text-xl">3</span>
            </div>
            <div>
              <h4 className="font-medium text-foreground text-lg">Education-Driven Trust</h4>
              <p className="text-muted-foreground mt-2 leading-relaxed">
                Launch 4 campaigns explaining how features work in local languages with real user stories
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OverviewSection;