import { useState } from "react";

const campaigns = [
  { id: "step-by-step", icon: "📹", title: "Step by Step", subtitle: "30-second videos" },
  { id: "your-language", icon: "🌍", title: "Your Language", subtitle: "Local language guides" },
  { id: "real-stories", icon: "💬", title: "Real Stories", subtitle: "Community trust" },
  { id: "first-success", icon: "🎉", title: "First Success", subtitle: "Success triggers" },
];

const TrustCampaignsSection = () => {
  const [activeCampaign, setActiveCampaign] = useState("step-by-step");

  return (
    <div className="space-y-8 animate-fade-in">
      <p className="text-muted-foreground text-lg max-w-2xl">
        Four campaigns to improve understanding, confidence, and Trustpilot ratings
      </p>

      {/* Campaign Tabs */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {campaigns.map((campaign) => (
          <button
            key={campaign.id}
            onClick={() => setActiveCampaign(campaign.id)}
            className={`p-5 rounded-xl text-left transition-all ${
              activeCampaign === campaign.id
                ? "gradient-bg text-white shadow-lg"
                : "bg-card border border-border hover:border-primary/50"
            }`}
          >
            <span className="text-2xl">{campaign.icon}</span>
            <h4 className={`font-medium mt-3 ${activeCampaign === campaign.id ? "text-white" : "text-foreground"}`}>
              {campaign.title}
            </h4>
            <p className={`text-sm mt-1 ${activeCampaign === campaign.id ? "text-white/80" : "text-muted-foreground"}`}>
              {campaign.subtitle}
            </p>
          </button>
        ))}
      </div>

      {/* Campaign Content */}
      <div className="bg-card rounded-xl border border-border p-8 md:p-10">
        {activeCampaign === "step-by-step" && (
          <div className="space-y-6 animate-fade-in">
            <div>
              <h3 className="font-serif text-2xl text-foreground">"Your Money, Step by Step"</h3>
              <p className="text-muted-foreground mt-2">30-second vertical videos showing exactly how features work</p>
            </div>
            
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <h4 className="font-medium text-foreground mb-3">What It Is</h4>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  Simple visuals + voice-over showing one clear action per video. No text-heavy explanations.
                </p>
                
                <h4 className="font-medium text-foreground mt-6 mb-3">Example Videos</h4>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li className="flex items-start gap-2"><span className="text-primary">→</span>"How to pay NEPA bill from UK in 30 seconds"</li>
                  <li className="flex items-start gap-2"><span className="text-primary">→</span>"How Paystro marketplace keeps your money safe"</li>
                  <li className="flex items-start gap-2"><span className="text-primary">→</span>"Where your money goes after you press send"</li>
                </ul>
              </div>
              
              <div>
                <h4 className="font-medium text-foreground mb-3">Why This Works</h4>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li>✓ Reduces fear of new technology</li>
                  <li>✓ Builds confidence through transparency</li>
                  <li>✓ Makes Paystro feel human and trustworthy</li>
                </ul>
                
                <div className="bg-info-bg border border-info/20 rounded-lg p-5 mt-6">
                  <h4 className="font-medium text-foreground text-sm">Trustpilot Impact</h4>
                  <p className="text-muted-foreground text-sm mt-2">
                    End each video with: "If Paystro helped you today, please share your experience on Trustpilot."
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeCampaign === "your-language" && (
          <div className="space-y-6 animate-fade-in">
            <div>
              <h3 className="font-serif text-2xl text-foreground">"Paystro Explained in Your Language"</h3>
              <p className="text-muted-foreground mt-2">One-page visual guides in local languages</p>
            </div>
            
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <h4 className="font-medium text-foreground mb-3">What It Is</h4>
                <p className="text-muted-foreground text-sm leading-relaxed mb-4">
                  Simple visual guides explaining wallet, bill payments, and marketplace safety in:
                </p>
                <div className="flex flex-wrap gap-2">
                  {["Pidgin", "Yoruba", "Igbo", "Hausa", "Benin", "Urhobo"].map((lang) => (
                    <span key={lang} className="bg-primary/10 text-primary px-3 py-1 rounded-full text-sm">
                      {lang}
                    </span>
                  ))}
                </div>
                
                <h4 className="font-medium text-foreground mt-6 mb-3">Design Principles</h4>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li className="flex items-start gap-2"><span className="text-primary">→</span>Icons, arrows, and pictures (minimal text)</li>
                  <li className="flex items-start gap-2"><span className="text-primary">→</span>Large fonts for easy reading</li>
                  <li className="flex items-start gap-2"><span className="text-primary">→</span>WhatsApp-shareable PDF or image format</li>
                </ul>
              </div>
              
              <div>
                <h4 className="font-medium text-foreground mb-3">Why This Works</h4>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li>✓ Language = trust in financial services</li>
                  <li>✓ Shows deep cultural respect</li>
                  <li>✓ Reaches users uncomfortable with "banking language"</li>
                </ul>
                
                <div className="bg-info-bg border border-info/20 rounded-lg p-5 mt-6">
                  <h4 className="font-medium text-foreground text-sm">Trustpilot Impact</h4>
                  <p className="text-muted-foreground text-sm mt-2">
                    Users who feel "this app is for people like me" are significantly more likely to leave positive reviews.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeCampaign === "real-stories" && (
          <div className="space-y-6 animate-fade-in">
            <div>
              <h3 className="font-serif text-2xl text-foreground">"Real Stories, Real Bills"</h3>
              <p className="text-muted-foreground mt-2">Community trust through authentic user stories</p>
            </div>
            
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <h4 className="font-medium text-foreground mb-3">What It Is</h4>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  Short, genuine stories from real users via text, voice notes, or simple selfie videos.
                </p>
                
                <h4 className="font-medium text-foreground mt-6 mb-3">Example Stories</h4>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li className="flex items-start gap-2"><span className="text-primary">→</span>"I paid my mum's electricity from London"</li>
                  <li className="flex items-start gap-2"><span className="text-primary">→</span>"I used the marketplace and got better rates"</li>
                  <li className="flex items-start gap-2"><span className="text-primary">→</span>"My money didn't disappear—I could see every step"</li>
                </ul>
              </div>
              
              <div>
                <h4 className="font-medium text-foreground mb-3">Why This Works</h4>
                <p className="text-muted-foreground text-sm font-medium mb-3">People trust people, not apps.</p>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li>✓ Word-of-mouth &gt; polished marketing</li>
                  <li>✓ Real voices &gt; corporate advertising</li>
                  <li>✓ Community validation drives fintech adoption</li>
                </ul>
                
                <div className="bg-info-bg border border-info/20 rounded-lg p-5 mt-6">
                  <h4 className="font-medium text-foreground text-sm">Trustpilot Impact</h4>
                  <p className="text-muted-foreground text-sm mt-2">
                    "Would you be willing to share this on Trustpilot to help others like you?"
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeCampaign === "first-success" && (
          <div className="space-y-6 animate-fade-in">
            <div>
              <h3 className="font-serif text-2xl text-foreground">"First Bill Paid" Trust Trigger</h3>
              <p className="text-muted-foreground mt-2">Capture reviews at moment of peak trust</p>
            </div>
            
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <h4 className="font-medium text-foreground mb-3">What It Is</h4>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  After a user completes their first successful bill payment or marketplace trade, show:
                </p>
                
                <div className="bg-muted rounded-xl p-6 mt-4 text-center">
                  <span className="text-4xl">🎉</span>
                  <p className="font-medium text-foreground mt-3">"You've just completed your first successful transaction!"</p>
                  <p className="text-muted-foreground text-sm mt-3">"Would you like to help others by sharing your experience?"</p>
                </div>
              </div>
              
              <div>
                <h4 className="font-medium text-foreground mb-3">Why This Works</h4>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li>✓ Moment of success = highest emotional trust</li>
                  <li>✓ Reviews written now are more positive and specific</li>
                  <li>✓ Users want to share good experiences immediately</li>
                  <li>✓ Natural, not forced or transactional</li>
                </ul>
                
                <div className="bg-info-bg border border-info/20 rounded-lg p-5 mt-6">
                  <h4 className="font-medium text-foreground text-sm">Trustpilot Impact</h4>
                  <p className="text-muted-foreground text-sm mt-2">
                    Captures peak emotional trust. Reviews are more detailed, enthusiastic, and credible.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default TrustCampaignsSection;