import { Receipt, Globe } from "lucide-react";

const WalletStrategySection = () => {
  return (
    <div className="space-y-12 animate-fade-in">
      {/* Strategy Cards */}
      <div className="grid lg:grid-cols-2 gap-8">
        {/* Wallet-First Bill Payments */}
        <div className="bg-card rounded-xl border border-border p-8 hover:shadow-lg transition-shadow">
          <div className="flex items-center gap-4 mb-6">
            <div className="w-14 h-14 bg-secondary/10 rounded-xl flex items-center justify-center">
              <Receipt className="w-8 h-8 text-secondary" />
            </div>
            <div>
              <h3 className="font-serif text-xl text-foreground">Wallet-First Bill Payments</h3>
              <div className="flex gap-2 mt-2">
                <span className="text-xs bg-secondary/10 text-secondary px-3 py-1 rounded-full">Purpose-Based</span>
                <span className="text-xs bg-secondary/10 text-secondary px-3 py-1 rounded-full">Recurring</span>
              </div>
            </div>
          </div>
          
          <div className="bg-problem-bg border-l-4 border-problem rounded-r-lg p-5 mb-6">
            <h4 className="font-medium text-foreground mb-2"><span className="text-xl">👨🏽</span> The Problem</h4>
            <p className="text-muted-foreground text-sm leading-relaxed">
              Diaspora users send money hoping it's used for bills like electricity or school fees. 
              This creates <strong className="text-foreground">stress and uncertainty</strong> about whether 
              the money reached its intended purpose.
            </p>
          </div>
          
          <div className="bg-opportunity-bg border-l-4 border-opportunity rounded-r-lg p-5">
            <h4 className="font-medium text-foreground mb-2">💡 The Opportunity</h4>
            <p className="text-muted-foreground text-sm leading-relaxed mb-3">
              Shift from people-based transfers to purpose-based payments. Let users:
            </p>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li className="flex items-start gap-2">
                <span className="text-primary mt-0.5">→</span>
                Pay bills directly from their wallet
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary mt-0.5">→</span>
                Schedule recurring payments
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary mt-0.5">→</span>
                Name payments ("Mum's NEPA Bill", "Cousin's school fees")
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary mt-0.5">→</span>
                See payment history and status
              </li>
            </ul>
            <p className="text-sm text-muted-foreground mt-4">
              <strong className="text-foreground">Impact:</strong> Turns Paystro into a problem-solving 
              tool for families, not just a transfer app.
            </p>
          </div>
        </div>

        {/* P2P Wallet Integration */}
        <div className="bg-card rounded-xl border border-border p-8 hover:shadow-lg transition-shadow">
          <div className="flex items-center gap-4 mb-6">
            <div className="w-14 h-14 bg-primary/10 rounded-xl flex items-center justify-center relative">
              <Globe className="w-8 h-8 text-primary" />
              <span className="absolute -top-1 -right-1 w-3 h-3 bg-primary rounded-full animate-pulse"></span>
              <span className="absolute -bottom-1 -left-1 w-2 h-2 bg-primary/60 rounded-full"></span>
              <span className="absolute top-1/2 -right-2 w-2 h-2 bg-primary/40 rounded-full"></span>
            </div>
            <div>
              <h3 className="font-serif text-xl text-foreground">P2P Wallet Integration</h3>
              <div className="flex gap-2 mt-2">
                <span className="text-xs bg-primary/10 text-primary px-3 py-1 rounded-full">Escrow</span>
                <span className="text-xs bg-primary/10 text-primary px-3 py-1 rounded-full">Trust Signals</span>
              </div>
            </div>
          </div>
          
          <div className="bg-problem-bg border-l-4 border-problem rounded-r-lg p-5 mb-6">
            <h4 className="font-medium text-foreground mb-2"><span className="text-xl">👩🏽</span> The Problem</h4>
            <p className="text-muted-foreground text-sm leading-relaxed">
              P2P marketplaces offer better rates, but users don't trust them because they 
              <strong className="text-foreground"> can't see where money is</strong> or what happens 
              if something goes wrong.
            </p>
          </div>
          
          <div className="bg-opportunity-bg border-l-4 border-opportunity rounded-r-lg p-5">
            <h4 className="font-medium text-foreground mb-2">💡 The Opportunity</h4>
            <p className="text-muted-foreground text-sm leading-relaxed mb-3">
              Integrate marketplace fully into the wallet as a safe, transparent middle layer:
            </p>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li className="flex items-start gap-2">
                <span className="text-primary mt-0.5">→</span>
                Hold funds safely: Wallet acts as escrow
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary mt-0.5">→</span>
                Show progress: "Money waiting" → "Trader sent naira" → "Released"
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary mt-0.5">→</span>
                Show trader stats (Completed trades, Speed, Success rate)
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary mt-0.5">→</span>
                Auto-match with best available traders
              </li>
            </ul>
            <p className="text-sm text-muted-foreground mt-4">
              <strong className="text-foreground">Impact:</strong> Transforms complex marketplace 
              into simple, safe experience.
            </p>
          </div>
        </div>
      </div>

      {/* Why This Works Banner */}
      <div className="gradient-bg rounded-xl p-8 md:p-12 text-center">
        <h3 className="font-serif text-2xl md:text-3xl text-white mb-4">Why This Works</h3>
        <p className="text-white/90 max-w-2xl mx-auto leading-relaxed">
          Paystro already has bill-pay rails and is building wallet features. Small product changes 
          unlock massive user value by addressing real diaspora pain points.
        </p>
      </div>
    </div>
  );
};

export default WalletStrategySection;