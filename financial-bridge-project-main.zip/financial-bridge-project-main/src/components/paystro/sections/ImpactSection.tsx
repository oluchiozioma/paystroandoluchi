const ImpactSection = () => {
  return (
    <div className="space-y-12 animate-fade-in">
      {/* Impact Banner */}
      <div className="gradient-bg rounded-xl p-8 md:p-12">
        <p className="text-white/90 text-center max-w-2xl mx-auto mb-8">
          How wallet integration + education campaigns drive business outcomes
        </p>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {[
            { number: "↑ Understanding", label: "Users comprehend features" },
            { number: "↑ Trust", label: "Organic Trustpilot growth" },
            { number: "↑ Retention", label: "Purpose-driven usage" },
            { number: "↑ Differentiation", label: "Stronger competitive moat" },
          ].map((stat, index) => (
            <div key={index} className="bg-white/10 backdrop-blur-sm rounded-lg p-5 text-center">
              <p className="text-white font-serif text-lg md:text-xl">{stat.number}</p>
              <p className="text-white/80 text-xs md:text-sm mt-2">{stat.label}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Timeline */}
      <div className="grid md:grid-cols-3 gap-8">
        <div className="bg-card rounded-xl border border-border p-8 hover:shadow-lg transition-shadow">
          <div className="w-10 h-10 rounded-full bg-secondary/10 flex items-center justify-center mb-4">
            <span className="text-secondary font-serif">1</span>
          </div>
          <h3 className="font-serif text-xl text-foreground mb-4">Short-Term Wins</h3>
          <p className="text-muted-foreground text-sm mb-4">0-3 months</p>
          <ul className="space-y-3 text-sm text-muted-foreground">
            <li className="flex items-start gap-2"><span className="text-primary">→</span>Launch wallet-integrated bill payments</li>
            <li className="flex items-start gap-2"><span className="text-primary">→</span>Release 3-5 educational videos</li>
            <li className="flex items-start gap-2"><span className="text-primary">→</span>Deploy "first success" Trustpilot triggers</li>
            <li className="flex items-start gap-2"><span className="text-primary">→</span>Create language guides for Nigeria</li>
          </ul>
        </div>

        <div className="bg-card rounded-xl border border-border p-8 hover:shadow-lg transition-shadow">
          <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center mb-4">
            <span className="text-primary font-serif">2</span>
          </div>
          <h3 className="font-serif text-xl text-foreground mb-4">Medium-Term Growth</h3>
          <p className="text-muted-foreground text-sm mb-4">3-6 months</p>
          <ul className="space-y-3 text-sm text-muted-foreground">
            <li className="flex items-start gap-2"><span className="text-primary">→</span>Full P2P marketplace wallet integration</li>
            <li className="flex items-start gap-2"><span className="text-primary">→</span>Expand language guides to Ghana & Kenya</li>
            <li className="flex items-start gap-2"><span className="text-primary">→</span>Launch community stories campaign</li>
            <li className="flex items-start gap-2"><span className="text-primary">→</span>Measure Trustpilot rating improvement</li>
          </ul>
        </div>

        <div className="bg-card rounded-xl border border-border p-8 hover:shadow-lg transition-shadow">
          <div className="w-10 h-10 rounded-full bg-amber-500/10 flex items-center justify-center mb-4">
            <span className="text-amber-600 font-serif">3</span>
          </div>
          <h3 className="font-serif text-xl text-foreground mb-4">Long-Term Vision</h3>
          <p className="text-muted-foreground text-sm mb-4">6+ months</p>
          <ul className="space-y-3 text-sm text-muted-foreground">
            <li className="flex items-start gap-2"><span className="text-primary">→</span>Wallet becomes central product hub</li>
            <li className="flex items-start gap-2"><span className="text-primary">→</span>Market leadership in UK-Africa corridors</li>
            <li className="flex items-start gap-2"><span className="text-primary">→</span>Strong brand as "trusted diaspora tool"</li>
            <li className="flex items-start gap-2"><span className="text-primary">→</span>Network effects from marketplace liquidity</li>
          </ul>
        </div>
      </div>

      {/* Success Metrics */}
      <div className="bg-card rounded-xl border border-border p-8 md:p-10">
        <h3 className="font-serif text-2xl text-foreground mb-8">Key Success Metrics</h3>
        <div className="grid md:grid-cols-2 gap-6">
          <div className="bg-muted rounded-lg p-5">
            <h4 className="font-medium text-foreground mb-2">Product Adoption</h4>
            <p className="text-muted-foreground text-sm">
              % of users using bill payments, marketplace adoption rate, wallet active users
            </p>
          </div>
          <div className="bg-muted rounded-lg p-5">
            <h4 className="font-medium text-foreground mb-2">Trust & Satisfaction</h4>
            <p className="text-muted-foreground text-sm">
              Trustpilot rating improvement, NPS score, review volume growth
            </p>
          </div>
          <div className="bg-muted rounded-lg p-5">
            <h4 className="font-medium text-foreground mb-2">Retention</h4>
            <p className="text-muted-foreground text-sm">
              Repeat usage rate, bill payment frequency, marketplace repeat transactions
            </p>
          </div>
          <div className="bg-muted rounded-lg p-5">
            <h4 className="font-medium text-foreground mb-2">Education Impact</h4>
            <p className="text-muted-foreground text-sm">
              Video view-through rates, guide downloads, language preference data
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ImpactSection;